import React from 'react';

const About = () => {
  return (
    <div>
        <section className="about" style={{backgroundImage: "url(best-watches-bg.jpg)"}}>
            <div className="about-content">
                <h2 className="fade-in">About US</h2>
                <p>Welcome to wWatch World, share we belive a watch is more than just an accessory it is a statment of style, precision, and crafsmanship. Our mission is to bring you a diverse selection of premium timepieces from around the globe, each chosen for its quality and unique design. we are here to help you find the perfect piece to complement your personality and elevate your look.</p>
            </div>
        </section>
    </div>
  );
}

export default About;
