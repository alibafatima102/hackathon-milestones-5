
import HomeContent from "@/components/HomeContent";

export default function Home() {
  return (
    <div>
     <HomeContent /> 
    </div>
  );
}
